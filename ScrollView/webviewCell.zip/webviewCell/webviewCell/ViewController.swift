//
//  ViewController.swift
//  webviewCell
//
//  Created by alexfu on 7/15/17.
//  Copyright © 2017 alexfu. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {
    var articleHigh:CGFloat = 44.0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 9 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "webcell", for: indexPath)
                as! webCell
            cell.delegate = self
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "textcell", for: indexPath) as! textCell
            return cell
        }
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
       // let cell =  tableView.cellForRow(at: indexPath)
        if indexPath.row == 9  {
            return articleHigh
        }
        return 44
    }


}


extension ViewController:webCellDelegate {
    func celHeight(_ cell:UITableViewCell, height:CGFloat)
    {
        let indexPath = tableView.indexPath(for: cell)
        
        if cell.frame.size.height != height {
            print(height)
            articleHigh = height
            tableView.reloadRows(at: [indexPath!], with: .none)
        }
        
        
    }
    
    
}

